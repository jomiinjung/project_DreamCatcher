/* chart 옵션 */
// color
const bgColorful = [
	'rgba(255, 99, 132, 0.3)',
    'rgba(54, 162, 235, 0.3)',
    'rgba(255, 206, 86, 0.3)',
    'rgba(75, 192, 192, 0.3)',
    'rgba(153, 102, 255, 0.3)',
    'rgba(255, 159, 64, 0.3)'
];
const borderColorful = [
	'rgba(255, 99, 132, 1)',
    'rgba(54, 162, 235, 1)',
    'rgba(255, 206, 86, 1)',
    'rgba(75, 192, 192, 1)',
    'rgba(153, 102, 255, 1)',
    'rgba(255, 159, 64, 1)'
];
const bgYellow = ['rgba(255, 211, 79, 0.6)','rgba(255, 198, 27, 0.6)'];
const borderYellow = ['rgba(255, 211, 79, 1)','rgba(255, 198, 27, 1)'];
const bgPinkBlue = ['rgba(54, 162, 235, 0.5)','rgba(255, 99, 132, 0.5)'];
const borderPinkBlue = ['rgba(54, 162, 235, 1)','rgba(255, 99, 132, 1)'];
const bgPurpleGreen = ['rgba(153, 102, 255, 0.5)','rgba(75,192,192, 0.5)'];
const borderPurpleGreen = ['rgba(153, 102, 255, 1)','rgba(75,192,192, 1)'];
const bgBlue = ['rgba(151, 185, 224, 0.3)','rgba(151, 185, 224, 0.5)','rgba(151, 185, 224, 0.7)','rgba(80, 137, 188, 0.5)','rgba(80, 137, 188, 0.7)','rgba(80, 137, 188, 0.9)'];
const borderBlue = ['rgba(151, 185, 224, 0.7)','rgba(80, 137, 188, 0.7)'];
const bgGreen = ['rgba(161, 196, 144, 0.5)','rgba(161, 196, 144, 0.7)','rgba(98, 153, 62, 0.5)','rgba(98, 153, 62, 0.65)','rgba(98, 153, 62, 0.75)','rgba(98, 153, 62, 0.9)'];
const borderGreen = ['rgba(161, 196, 144, 0.7)','rgba(98, 153, 62, 0.7)'];
// label
const label= ['매우 불만족','불만족','보통','만족','매우 만족'];
const labelSat = ['매우 불만족','불만족','보통','만족','매우 만족'];
const labelWorking = ['취업','미취업'];
const labelMarriage = ['미혼','기혼'];
const labelEmployType = ['정규직','비정규직'];
const labelGender = ['남성','여성'];

// 높은 비율을 차지하는 항목
const findMaxAndIndex = function(arr){
	 if (!Array.isArray(arr) || arr.length === 0) {
		// 유효하지 않은 입력 처리
	    return null; 
	  }
	 let max = arr[0];
	 let maxIndex = 0;
	 
	 for (let i = 1; i < arr.length; i++) {
	    if (arr[i] > max) {
	      max = arr[i];
	      maxIndex = i;
	    }
	  }

	  return { max, maxIndex };
}

// options
const pieGraphOption = function(unit){
	const opt = {
	// 기본 옵션
		responsive:false,
		maintainAspectRatio: false,
		tooltips: {
		    callbacks: {
		        label: function(tooltipItem, data) {
		        	var dataIndex = tooltipItem.index; 
		            var dataset = data.datasets[0];
		        	var label = data.labels[dataIndex];
		        	var value = dataset.data[dataIndex];

		            return label + ': ' + value + unit;
		        }
		    },
		    titleFontSize: 13,
		    bodyFontSize: 13
		},
		legend: {
		    display: false,
		    labels: {
		        color: 'rgb(255, 99, 132)',
		        font: {
		            size: 14
		        }
		    },
		    position:'bottom',
		}
	}
	
	return opt;
}

let graphOption = function(minVal,maxVal,stepVal,unit){
	const opt =  {
		// 만족도 bar 그래프 옵션
	    responsive:false,
	    maintainAspectRatio: false,
	    tooltips: {
            callbacks: {
                label: function(tooltipItem, data) {
                	var datasetIndex = tooltipItem.datasetIndex; // 현재 데이터셋의 인덱스
                    var datasetLabel = data.datasets[datasetIndex].label; // 현재 데이터셋의 라벨

                    var value = tooltipItem.yLabel;

                	//console.log(datasetLabel);
                    return datasetLabel + ': ' + value + unit;
                }
            },
            titleFontSize: 14,
            bodyFontSize: 14
        },
	    scales: {
	        yAxes: [{
	           ticks: {
	              min: minVal,
	              max: maxVal,
	              stepSize : stepVal,
	              fontSize : 14,
	           }
	        }]
	     },
	    legend: {
	        display: false,
	    }
	}
	return opt;
}

/* chart 출력 */
/* 선택 시 결과를 jsp 파일에 뿌려주기 위한 요소 생성 */
let createElementGraph = function(index,canvas){
	const elGraph = '<li class="graph-item item'+ index +'">'
		+ '<div class="result-graph">' + '<div class="box-chart">'
		+ '<canvas id="'+ canvas + index +'"></canvas>'
		+ '</div></div></li>';
		
	return elGraph;
}
let createElementDesc = function(title,item,value,unit){
	const elDesc = '<li class="result-item">'
		+'<div class="title">'+ title +'<span> : </span></div>'
		+'<div class="highest-item">'
		+'<span class="name">'+item+'</span>'
		+' <span class="value">'+value+'</span>'
		+'<span class="unit">'+unit+'</span>'
		+'</div></li>';
		
	return elDesc;
}
// 만족도 영역
let createPieElement = function(index,title,canvas,item,value){
	const elSatisfaction = '<li class="graph-item item'+ index +'">'
		+ '<div class="result-text">'
		+ '<div class="title">' + title + '</div>'
		+ '<div class="highest-item">' + '<span class="name">'+item+'</span>'
		+ '<span class="percent">'+value+'%</span>' + '</div>' + '</div>'
		+ '<div class="result-graph">' + '<div class="box-chart">'
		+ '<canvas id="'+ canvas + index +'"></canvas>'
		+ '</div></div></li>';
		
		return elSatisfaction;
}

//노출 그래프 갯수에 따라 레이아웃 변경
const showList = function(length){
	if(length == 2){
		$(".graphs").removeClass("item-6").addClass("item-2");
		$(".item3").hide();
		$(".item4").hide();
		$(".item5").hide();
		$(".item6").hide();
	}else{
		$(".graphs").removeClass("item-2").addClass("item-6");
		$(".item3").show();
		$(".item4").show();
		$(".item5").show();
		$(".item6").show();
	}
}

const hideWorkContent = function(){
	$('.contents.sat-leisure').removeClass("w50").addClass("w100");
	$('.contents.sat-job').hide();
	$('.contents.working').hide();
	$('.contents.wage').hide();
	$('.contents.workingHour').hide();
	$('.contents.employType').hide();
}
const showWorkContent = function(){
	$('.contents.sat-leisure').removeClass("w100").addClass("w50");
	$('.contents.sat-job').show();
	$('.contents.working').show();
	$('.contents.wage').show();
	$('.contents.workingHour').show();
	$('.contents.employType').show();
}

/* page animation */
$.fn.isInViewport = function() {
    var elementTop = $(this).offset().top;
    var elementBottom = elementTop + $(this).outerHeight();

    var viewportTop = $(window).scrollTop();
    var viewportBottom = viewportTop + $(window).height();

    return elementBottom > viewportTop + 50 && elementTop < viewportBottom -50;

};
$(document).ready(function(){
	chartAnimation();
	$(window).scrollTop(0);
});
$(".comparison-item label").click(function(){
	chartAnimation();
	$(window).scrollTop(0);
});

function chartAnimation(){
	if(!$(".graphs").hasClass("active")) $(".graphs").addClass("active");
	if(!$(".info-select").hasClass("hide")) $(".info-select").addClass("hide");
	
	var target = document.querySelector('.graphs');
	var player = target.animate([
	    { transform: 'translateY(50px)', opacity:'0',paddingTop:'50px'},
	    {  transform: 'translateY(0)', opacity:'1', paddingTop:'0'}
	],{
	    duration : 400,
	    fillMode: 'forwards'
	});
}