var replys = [
    {replyId: 1, postId: 1, content: "첫 번째 댓글 댓글이 아주 길면 얼마나 내려가는지 확인-----------------------", author: "IDID" },
    {replyId: 2, postId: 1, content: "두 번째 댓글", author: "KIMHAHA" },
    {replyId: 3, postId: 1, content: "세 번째", author: "IDID" },
    {replyId: 4, postId: 1, content: "네 번째 댓글", author: "KIMHAHA" },
    {replyId: 5, postId: 1, content: "다섯", author: "IDID" },
    {replyId: 6, postId: 1, content: "여섯", author: "IDID" },
    {replyId: 7, postId: 1, content: "일곱", author: "KIMHAHA" },
    {replyId: 8, postId: 1, content: "여덟", author: "IDID" },
    {replyId: 9, postId: 1, content: "아홉", author: "KIMHAHA" },
    {replyId: 10, postId: 1, content: "열", author: "IDID" },
    {replyId: 11, postId: 1, content: "댓글", author: "IDID" },
    {replyId: 12, postId: 1, content: "댓글", author: "KIMHAHA" },
    {replyId: 13, postId: 1, content: "시비", author: "IDID" },
    {replyId: 14, postId: 1, content: "댓글", author: "KIMHAHA" },
    {replyId: 15, postId: 1, content: "가장 최신 댓글", author: "IDID" },
];

function replyPage(currentPage) { // 현재 페이지를 매개변수로 게시글/페이지네이션 표시.

    var tableBody = document.querySelector("#reply-table tbody");
    tableBody.replaceChildren();

    let totalReply = replys.length; // 총 댓글 수

    let page_num = 10; // 페이지네이션 최대 수

    var totalPage = Math.ceil(totalReply / page_num); // 총 페이지네이션 수

    let pageGroup = Math.ceil(currentPage / page_num); // 현재 페이지가 몇 번째 그룹인지

    let lastPage = pageGroup * page_num;
    if (lastPage > totalPage) { lastPage = totalPage };
    let firstPage = lastPage - (page_num - 1);
    if (firstPage < 0) { firstPage = 1 };

    let pages = document.querySelector(".paginate .pageNo");
    pages.replaceChildren();

    for (let i = firstPage; i <= lastPage; i++) { // 페이지네이션 생성
        if (i == currentPage) {
            pages.innerHTML += `<button class="pageNumber currentPage" id="page_${i}">${i}</button>`
        } else pages.innerHTML += `<button class="pageNumber" id="page_${i}" onclick=replyPage(${i})>${i}</button>`
    }

    for (var i = (currentPage*10)-10; i < currentPage*10; i++) {
        var row = document.createElement("tr");

        var authorCell = document.createElement("td"); // 글쓴이
        authorCell.setAttribute('style', 'border:0; width:15%;');
        authorCell.textContent = replys[i].author;

        var contentCell = document.createElement("td"); // 내용
        contentCell.setAttribute('style', 'border:0; width:65%');
        contentCell.textContent = replys[i].content;

        var deleteBtn = document.createElement("td"); // 삭제 버튼
        deleteBtn.setAttribute('class', 'text-center content btn btn-xs btn-danger pull-right')
        deleteBtn.setAttribute('style', 'margin-right:10%');
        deleteBtn.textContent = `삭제`;

        row.appendChild(authorCell);
        row.appendChild(contentCell);
        row.appendChild(deleteBtn);

        tableBody.appendChild(row);
    }
};

window.onload = replyPage(1);