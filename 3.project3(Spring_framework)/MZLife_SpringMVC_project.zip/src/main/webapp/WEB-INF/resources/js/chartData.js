
function getRatio (calSat,factor) {
	fetch("factorDetail.do?sat="+calSat+"&factor="+factor)
		.then(response => {
			console.log(response);
			return response.json()
		})
		.then(data => {
			console.log(data)
		})
		.catch(err => {
			console.log("error : "+err)
		});
}