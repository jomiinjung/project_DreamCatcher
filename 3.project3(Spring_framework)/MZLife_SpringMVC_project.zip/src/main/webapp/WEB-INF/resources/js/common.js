
$.fn.isInViewport = function() {
    var elementTop = $(this).offset().top;
    var elementBottom = elementTop + $(this).outerHeight();

    var viewportTop = $(window).scrollTop();
    var viewportBottom = viewportTop + $(window).height();

    return elementBottom > viewportTop + 50 && elementTop < viewportBottom + 50;

};

$(window).on('load resize scroll',function(){
	if($('.function1').hasClass("active")){
        $('.ani').each(function(){
            if($(this).isInViewport()){
                $(this).addClass('active');
            }
        });
	}
});

function submitBtn(e){
	const popupWrap = e.parentNode.parentNode.parentNode;
	console.log(popupWrap.classList);
	popupWrap.style.display = "none";
//	document.forms['sat_info'].submit().hide();
}

const loadingClose = function(){
	document.querySelector("#loading").classList.add("hide");
}
const timeoutLoad = function(){
	document.querySelector("#loading").classList.remove("hide").add("active");
	setTimeout(loadingClose(),1500);
}


function closePop() {
    document.forms['sat_info'].submit();
    document.all['wrapPopup'].style.visibility = "hidden";
    timeoutLoad();
    document.querySelector(".function1").classList.add("active");
}