let infoConfirm = function(){
	const idInput = document.querySelector("#userId");
	const pwInput = document.querySelector("#userPw");
	const pwCheckInput = document.querySelector("#userPwCheck");
	const nameInput = document.querySelector("#userName");
	const emailInput = document.querySelector("#userEmail");
	const telInput = document.querySelector("#userTel");

	if(idInput.value.length == 0){
		alert("아이디는 필수 입력 사항입니다.");
		idInput.focus();
		return;
	}
	if(pwInput.value.length == 0){
		alert("비밀번호는 필수 입력 사항입니다.");
		pwInput.focus();
		return;
	}
	if(!isValidPassword(pwInput.value)){
		alert("비밀번호는 8~16자 영문, 숫자, 특수기호를 포함하여야 합니다.");
		pwInput.value = "";
		pwInput.focus();
		return;
	}
	if(pwInput.value != pwCheckInput.value){
		alert("비밀번호가 일치하지 않습니다.");
		pwCheckInput.value = "";
		pwCheckInput.focus();
		return;
	}
	if(nameInput.value.length == 0){
		alert("이름 필수 입력 사항입니다.");
		nameInput.focus();
		return;
	}
	if(emailInput.value.length == 0){
		alert("이메일은 필수 입력 사항입니다.");
		emailInput.focus();
		return;
	}
	if(!isValidEmail(emailInput.value)){
		alert("이메일 형식으로 입력해 주세요 ex) abc@google.com");
		emailInput.value = "";
		emailInput.focus();
		return;
	}
	if(telInput.value.length == 0){
		alert("휴대폰 번호는 필수 입력 사항입니다.");
		telInput.focus();
		return;
	}
	if(!isNumeric(telInput.value)){
		alert("휴대폰 번호는 숫자만 입력하실 수 있습니다.");
		telInput.value = "";
		telInput.focus();
		return;
	}
	
	// 조건 다 맞으면 submit
	document.reg_form.submit();
}

const changePwConfirm = function(){
	const pwInput = document.querySelector("#upw");
	const pwCheckInput = document.querySelector("#upwCheck");

	if(!isValidPassword(pwInput.value)){
		alert("비밀번호는 8~16자 영문, 숫자, 특수기호를 포함하여야 합니다.");
		pwInput.value = "";
		pwInput.focus();
		return;
	}
	if(pwInput.value != pwCheckInput.value){
		alert("비밀번호가 일치하지 않습니다.");
		pwCheckInput.value = "";
		pwCheckInput.focus();
		return;
	}
	
	// 조건 다 맞으면 submit
	document.change_pw.submit();
}

const isValidId = function (id) {
	// 영어와 숫자로만 구성되어 있는지  확인
	var alphanumericRegex = /^(?=.*[a-zA-Z])(?=.*[0-9])/;
	return alphanumericRegex.test(id);
}

const isValidPassword = function (pw) {
  // 8~16자 길이, 영문, 숫자, 특수기호 모두 포함
  var passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
  return passwordRegex.test(pw);
}

const isValidEmail = function(email) {
  // 이메일 형식인지 확인
	var atRegex = /@/;
	var dotRegex = /\./;
	return atRegex.test(email) && dotRegex.test(email);
}

const isNumeric = function (input) {
  // 숫자만으로 이루어져 있는지 확인
  var numericRegex = /^[0-9]+$/;
  return numericRegex.test(input);
}

function idCheck(){
	const idInput = document.querySelector("#userId");
	if(idInput.value.length<5){
		alert("아이디는 영문, 숫자 포함 5자 이상 입력해 주세요.");
		idInput.value = "";
		idInput.focus();
		return;
	}
	if(!isValidId(idInput.value)){
		alert("아이디는 영문과 숫자가 포함되어 있어야 합니다.");
		idInput.value = "";
		idInput.focus();
		return;
	}
	userIdCheckDupl();
}

/******** 중복확인 ***********/
function userIdCheckDupl() {
    var userIdValue = document.querySelector("#userId").value;
    var url = "idCheck.do?inputId=" + userIdValue;
    window.location.href = url;
}
