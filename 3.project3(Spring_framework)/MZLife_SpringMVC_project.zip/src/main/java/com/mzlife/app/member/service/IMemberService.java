package com.mzlife.app.member.service;

import com.mzlife.app.member.model.MemberVO;

public interface IMemberService {
	// 회원가입
	int insertMember(MemberVO member); 
	
	// id 중복확인
	String confirmId(String id);
	
	// 로그인
	int userCheck(String id,String pw);
	
	// 회원 정보 가져오기
	MemberVO getMember(String id); 
	
	// 아이디 찾기
	String getUserId(String name, String email); 
	
	// 비밀번호 변경 전 본인 확인
	String checkUserPw(String id, String name); 
	
	// 비밀번호 변경
	int updatePw(String pw, String id); 
	
	// 회원 정보 수정
	int updateMember(MemberVO member); 
	
	// 회원 탈퇴
	//int withdrawMember(String id);
}
