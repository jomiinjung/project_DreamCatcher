package com.mzlife.app.sts.dao;

import com.mzlife.app.sts.model.CompScoreVO;
import com.mzlife.app.sts.model.ConditionVO;
import com.mzlife.app.sts.model.FactorVO;
import com.mzlife.app.sts.model.RankFactorVO;

public interface IConditionRepository {
	// 사용자 정보 indert
	String insertCondition(ConditionVO cond);
	// r 연동해서 만족도 예측
	void predictLifeSat(String userId);
	// 사용자 정보 얻어옴
	ConditionVO getUserCond(String userId);
	// 정보 텍스트로 conversion
	ConditionVO conversionInfo(ConditionVO cond);
	// 같은 조건의 그룹의 평균 점수 얻어옴
	CompScoreVO getCompareScore(String userId);
	// 항목별 가중치 얻어옴
	FactorVO getFactor(String userId);
	// 상위 3개 항목
	RankFactorVO sortFactor(FactorVO factor);
}
