package com.mzlife.app.sts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.mzlife.app.sts.model.RatioVO;

@Repository
public class AnlysRepository implements IAnlysRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class AnlysMapper implements RowMapper<RatioVO> {
		@Override
		public RatioVO mapRow(ResultSet rs, int count) throws SQLException {
			ArrayList<Integer> satLife;
			ArrayList<Integer> satLeisure;
			ArrayList<Integer> satJob;
			ArrayList<Integer> working;
			ArrayList<Integer> marriage;
			ArrayList<Integer> employType;
			String criteria;
			String criteriaItem;
			int wage;
			int workingHour;
			
			// 선택 기준
			criteria = rs.getString("criteria");
			criteriaItem = rs.getString("criteriaVal");
			
			// 삶의 만족도
			satLife = new ArrayList<>();
			for(int i = 1; i<=5; i++) {
				satLife.add(rs.getInt("life_"+i));
			}
			// 여가생활 만족도
			satLeisure = new ArrayList<>();
			for(int i = 1; i<=5; i++) {
				satLeisure.add(rs.getInt("leisure_"+i));
			}
			// 직무 만족도
			satJob = new ArrayList<>();
			for(int i=1; i<=5; i++) {
				satJob.add(rs.getInt("job_"+i));
			}
			// 취업여부
			working = new ArrayList<>();
			working.add(rs.getInt("working_y"));
			working.add(rs.getInt("working_n"));
			// 혼인여부
			marriage = new ArrayList<>();
			marriage.add(rs.getInt("marriage_n"));
			marriage.add(rs.getInt("marriage_y"));
			// 고용형태(정규직/비정규직)
			employType = new ArrayList<>();
			employType.add(rs.getInt("rglworker_y"));
			employType.add(rs.getInt("rglworker_n"));
			
			wage = rs.getInt("wage_avg");
			workingHour = rs.getInt("workinghour_avg");
			
			RatioVO ratio = null;
			if(criteria.equals("life_satisfaction")) {
				// 삶의 만족도를 기준으로 그래프 생성 시 삶의 만족도는 null
				ratio = new RatioVO(criteria,criteriaItem,null,satLeisure,satJob,working,marriage,employType,wage,workingHour);
			}else if(criteria.equals("working")) {
				// 취업여부 기준으로 그래프 생성 시 직무만족도, 취업여부, 고용형태, 임금, 근무시간 null
				ratio = new RatioVO(criteria,criteriaItem,satLife,satLeisure,null,null,marriage,null,0,0);
			}else {
				ratio = new RatioVO(criteria,criteriaItem,satLife,satLeisure,satJob,working,marriage,employType,wage,workingHour);
			}
			return ratio;
		}
	}
	
	@Override
	public List<RatioVO> getRatio(String ct) {
		String sql = "select * from statdatas where criteria=?";
		return jdbcTemplate.query(sql, new AnlysMapper(),ct);
	}
}
