package com.mzlife.app.sts.model;

import java.util.ArrayList;

public class RatioVO {
	private String criteria;
	private String criteriaItem;
	private ArrayList<Integer> satLife;
	private ArrayList<Integer> satLeisure;
	private ArrayList<Integer> satJob;
	private ArrayList<Integer> working;
	private int wage;
	private ArrayList<Integer> marriage;
	private ArrayList<Integer> employType;
	private int workingHour;
	
	public RatioVO() {}
	public RatioVO(String criteria,String criteriaItem,ArrayList<Integer> satLife,ArrayList<Integer> satLeisure,ArrayList<Integer> satJob,ArrayList<Integer> working,ArrayList<Integer> marriage,ArrayList<Integer> employType,int wage,int workingHour) {
		this.criteria = criteria;
		this.criteriaItem = criteriaItem;
		this.satLife = satLife;
		this.satLeisure = satLeisure;
		this.satJob = satJob;
		this.working = working;
		this.marriage = marriage;
		this.employType = employType;
		this.wage = wage;
		this.workingHour = workingHour;
		
	}
	
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getCriteriaItem() {
		return criteriaItem;
	}
	public void setCriteriaItem(String criteriaItem) {
		this.criteriaItem = criteriaItem;
	}
	public ArrayList<Integer> getSatLife() {
		return satLife;
	}
	public void setSatLife(ArrayList<Integer> satLife) {
		this.satLife = satLife;
	}
	public ArrayList<Integer> getSatLeisure() {
		return satLeisure;
	}
	public void setSatLeisure(ArrayList<Integer> satLeisure) {
		this.satLeisure = satLeisure;
	}
	public ArrayList<Integer> getSatJob() {
		return satJob;
	}
	public void setSatJob(ArrayList<Integer> satJob) {
		this.satJob = satJob;
	}
	public ArrayList<Integer> getWorking() {
		return working;
	}
	public void setWorking(ArrayList<Integer> working) {
		this.working = working;
	}
	public int getWage() {
		return wage;
	}
	public void setWage(int wage) {
		this.wage = wage;
	}
	public ArrayList<Integer> getMarriage() {
		return marriage;
	}
	public void setMarriage(ArrayList<Integer> marriage) {
		this.marriage = marriage;
	}
	public ArrayList<Integer> getEmployType() {
		return employType;
	}
	public void setEmployType(ArrayList<Integer> employType) {
		this.employType = employType;
	}
	public int getWorkingHour() {
		return workingHour;
	}
	public void setWorkingHour(int workingHour) {
		this.workingHour = workingHour;
	}
	
}
