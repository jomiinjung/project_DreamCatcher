package com.mzlife.app.sts.dao;

import java.util.ArrayList;
import java.util.List;

import com.mzlife.app.sts.model.RatioVO;

public interface IAnlysRepository {
	public List<RatioVO> getRatio(String ct);
}
