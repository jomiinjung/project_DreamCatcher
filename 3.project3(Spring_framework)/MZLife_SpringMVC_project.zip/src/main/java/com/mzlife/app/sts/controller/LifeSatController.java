package com.mzlife.app.sts.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.mzlife.app.sts.model.CompScoreVO;
import com.mzlife.app.sts.model.ConditionVO;
import com.mzlife.app.sts.model.FactorVO;
import com.mzlife.app.sts.model.RankFactorVO;
import com.mzlife.app.sts.model.RatioVO;
import com.mzlife.app.sts.service.ILifeAnlysService;
import com.mzlife.app.sts.service.ILifeSatService;


@Controller
@RequestMapping(value="/anlys")
public class LifeSatController extends HttpServlet {
	
	@Autowired
	ILifeSatService satService; // 개인 만족도 분석
	@Autowired
	ILifeAnlysService anlysService; // mz 비교분석
	
	@RequestMapping(value="/satLife")
	public String checkHistory(ConditionVO cond,RedirectAttributes redirectAttr, HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		String id = (String)session.getAttribute("id");
		// 회원인지 확인 , 회원이면 전에 입력한 정보가 있는지 확인
		if(id!=null) {
			ConditionVO condition = satService.getUserCond(id);
			if(condition == null) {
				return "anlys/mz_satisfaction";
			}
			if(condition != null) {
				request.setAttribute("conditions", condition);
				redirectAttr.addAttribute("userId",id);
				return "redirect:/anlys/conversion";
			}
		}
		
		return "anlys/mz_satisfaction";
	}
	
	@RequestMapping(value="/insert")
	public String insertUser(ConditionVO cond,RedirectAttributes redirectAttr, HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		String id = (String)session.getAttribute("id");
		cond.setId(id);
		String userId = satService.insertCondition(cond);
		satService.predictLifeSat(userId);
		cond.setId(userId);
		redirectAttr.addAttribute("userId",userId);
		
		return "redirect:/anlys/conversion";
	}
	
	@RequestMapping(value="/conversion")
	public String getCondition(@RequestParam(value="userId")String userId,RedirectAttributes redirectAttr) {
		ConditionVO userInfo = satService.getUserCond(userId);
		ConditionVO conversionInfo = satService.conversionInfo(userInfo);
		
		redirectAttr.addFlashAttribute("user", conversionInfo);
		
		return "redirect:/anlys/factor";
	}
	
	@RequestMapping(value="/factor")
	public String getFactor(HttpServletRequest request,Model model) {
		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		ConditionVO user = (ConditionVO)flashMap.get("user");

		CompScoreVO compare = satService.getCompareScore(user.getId());
		FactorVO factor = satService.getFactor(user.getId());
		RankFactorVO ranking = satService.sortFactor(factor);
		
		model.addAttribute("user",user);
		model.addAttribute("avg",compare);
		model.addAttribute("factor",factor);
		model.addAttribute("ranking",ranking);
		model.addAttribute("visible","hide");
		
		return "anlys/mz_satisfaction";
	}

	@RequestMapping(value="/compare")
	public @ResponseBody List<RatioVO> getRatio(@RequestParam(value="comparison")String ct) {
		List<RatioVO> ratio = anlysService.getRatio(ct);
		
		return ratio;
	}
	
}
