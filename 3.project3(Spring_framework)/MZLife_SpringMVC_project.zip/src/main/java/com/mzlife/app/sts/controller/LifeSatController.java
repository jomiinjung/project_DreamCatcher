package com.mzlife.app.sts.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.mzlife.app.sts.model.CompScoreVO;
import com.mzlife.app.sts.model.ConditionVO;
import com.mzlife.app.sts.model.FactorVO;
import com.mzlife.app.sts.model.RankFactorVO;
import com.mzlife.app.sts.model.RatioVO;
import com.mzlife.app.sts.service.ILifeAnlysService;
import com.mzlife.app.sts.service.ILifeSatService;

// 주요 서비스 controller
@Controller
@RequestMapping(value="/anlys")
public class LifeSatController extends HttpServlet {
	
	@Autowired
	ILifeSatService satService; // 개인 만족도 분석
	@Autowired
	ILifeAnlysService anlysService; // mz 비교분석
	
	@RequestMapping(value="/satLife")
	public String checkHistory(ConditionVO cond,RedirectAttributes redirectAttr, HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		// 회원인지 확인 , 회원이면 전에 입력한 정보가 있는지 확인
		if(id!=null) {
			ConditionVO condition = satService.getUserCond(id);
			if(condition == null) {
				return "anlys/mz_satisfaction";
			}
			if(condition != null) {
				request.setAttribute("conditions", condition);
				redirectAttr.addAttribute("userId",condition.getId());
				return "redirect:/anlys/conversion";
			}
		}
		
		return "anlys/mz_satisfaction";
	}
	
	// 나의 만족도 알아보기 - 사용자 정보입력
	@RequestMapping(value="/insert")
	public String insertUser(ConditionVO cond,RedirectAttributes redirectAttr, HttpSession session, HttpServletRequest request) {
		// 로그인 상태인 경우 id 전달
		session = request.getSession();
		String id = (String)session.getAttribute("id");
		cond.setId(id);
		// 입력 정보 db에 insert
		String userId = satService.insertCondition(cond);
		// r 프로그램 연동해서 만족도 예측
		satService.predictLifeSat(userId);
		cond.setId(userId);
		redirectAttr.addAttribute("userId",userId);
		
		return "redirect:/anlys/conversion";
	}
	
	// 나의 만족도 알아보기 - 숫자형 데이터 문자형으로 전환
	@RequestMapping(value="/conversion")
	public String getCondition(@RequestParam(value="userId")String userId,RedirectAttributes redirectAttr, HttpSession session) {
		// 사용자 정보 받아옴
		ConditionVO userInfo = satService.getUserCond(userId);
		// 문자형으로 전환
		ConditionVO conversionInfo = satService.conversionInfo(userInfo);
		session.setAttribute("user", conversionInfo);
		redirectAttr.addFlashAttribute("user", conversionInfo);
		
		return "redirect:/anlys/factor";
	}
	
	// 나의 만족도 알아보기 - 영향 요인 별 영향의 정도 산출, 순위 산출
	@RequestMapping(value="/factor")
	public String getFactor(HttpServletRequest request,Model model, HttpSession session) {
		//Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		//ConditionVO user = (ConditionVO)flashMap.get("user");
		session = request.getSession();
		ConditionVO user = (ConditionVO)session.getAttribute("user");
		
		// 같은 조건 사람들의 평균값 받아옴
		CompScoreVO compare = satService.getCompareScore(user.getId());
		// 만족도 영향 요인별 가중치 받아옴
		FactorVO factor = satService.getFactor(user.getId());
		// 상위 3개의 요인을 순위를 매김
		RankFactorVO ranking = satService.sortFactor(factor);
		
		model.addAttribute("user",user);
		model.addAttribute("avg",compare);
		model.addAttribute("factor",factor);
		model.addAttribute("ranking",ranking);
		model.addAttribute("visible","hide");
		
		return "anlys/mz_satisfaction";
	}
	
	// mz 통계분석 - 선택 기준에 따라 수치 받아옴
	@RequestMapping(value="/compare")
	public @ResponseBody List<RatioVO> getRatio(@RequestParam(value="comparison")String ct) {
		List<RatioVO> ratio = anlysService.getRatio(ct);
		
		return ratio;
	}
	
}
