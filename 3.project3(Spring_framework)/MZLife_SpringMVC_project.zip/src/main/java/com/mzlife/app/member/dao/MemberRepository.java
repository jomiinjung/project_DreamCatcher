package com.mzlife.app.member.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.mzlife.app.member.model.MemberVO;

@Repository
public class MemberRepository implements IMemberRepository {

	public static final int MEMBER_JOIN_FAIL = 0;
	public static final int MEMBER_JOIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_PW_NO_GOOD = 0;
	public static final int MEMBER_LOGIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_IS_NOT = -1;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class MemberMapper implements RowMapper<MemberVO> {
		@Override
		public MemberVO mapRow(ResultSet rs, int count) throws SQLException {
			MemberVO user = new MemberVO();
			user.setId(rs.getString("id"));
			user.setPassword(rs.getString("password"));
			user.setName(rs.getString("name"));
			user.setEmail(rs.getString("email"));
			user.setPhone(rs.getInt("phone"));
			user.setAgree(rs.getString("agree"));
			user.setValidity(rs.getString("validity"));
			
			return user;
		}
	}
	
	// 회원가입
	@Override
	public int insertMember(MemberVO member) {
		String sql = "insert into users (id, password, name, email, phone, agree, validity)"
				+" values (?,?,?,?,?,?,?)";
		return jdbcTemplate.update(sql,
				member.getId(),
				member.getPassword(),
				member.getName(),
				member.getEmail(),
				member.getPhone(),
				member.getAgree(),
				member.getValidity()
		);
	}; 
	
	// id 중복확인
	@Override
	public String confirmId(String id) {
		String sql = "select id from users where id=?";
		try {
			jdbcTemplate.queryForObject(sql, String.class ,id);
			return "exist";
		}catch (IncorrectResultSizeDataAccessException error) {
			// 결과값이 없을 때
			return id;
		}
	};
	
	// 로그인
	@Override
	public int userCheck(String id,String pw) {
		String dbPw;
		String sql = "select password from users where id=?";
		
		try {
			dbPw = jdbcTemplate.queryForObject(sql, String.class ,id);
			if(pw.equals(dbPw)) {
				// 비밀번호 일치
				return MemberRepository.MEMBER_LOGIN_SUCCESS;
			}else {
				// 비밀번호 틀림
				return MemberRepository.MEMBER_LOGIN_PW_NO_GOOD;
			}
		}catch (IncorrectResultSizeDataAccessException error) {
			// 아이디 존재하지 않음
			return MemberRepository.MEMBER_LOGIN_IS_NOT;
		}
	};
	
	// 회원 정보 가져오기
	@Override
	public MemberVO getMember(String id) {
		String sql = "select * from users where id=?";
		try {
			return jdbcTemplate.queryForObject(sql, new MemberMapper() ,id);
		}catch (IncorrectResultSizeDataAccessException error) {
			return null;
		}
	}; 
	
	// 아이디 찾기
	@Override
	public String getUserId(String name, String email) {
		String id = null;
		String sql = "select id from users where name=? and email=?";
		try {
			return jdbcTemplate.queryForObject(sql, String.class ,name,email);
		}catch (IncorrectResultSizeDataAccessException error) {
			return null;
		}
	}; 
	
	// 비밀번호 변경 전 본인 확인
	@Override
	public String checkUserPw(String id, String name) {
		String sql = "select id from users where name=? and id=?";
		try {
			return jdbcTemplate.queryForObject(sql, String.class ,name,id);
		}catch (IncorrectResultSizeDataAccessException error) {
			return null;
		}
	}; 
	
	// 비밀번호 변경
	@Override
	public int updatePw(String pw, String id) {
		System.out.println("id : " + id);
		String sql = "update users set password= ? where id= ?";
		return jdbcTemplate.update(sql,pw,id);
	}; 
	
	// 회원 정보 수정
	@Override
	public int updateMember(MemberVO member) {
		String sql = "update users set password= ?, email= ?, phone= ? where id= ?";
		return jdbcTemplate.update(sql,
				member.getPassword(),
				member.getEmail(),
				member.getPhone(),
				member.getId()
			);
	}; 
	
	// 회원 탈퇴
	//int withdrawMember(String id);
}
