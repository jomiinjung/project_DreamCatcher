package com.mzlife.app.member.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mzlife.app.member.dao.IMemberRepository;
import com.mzlife.app.member.model.MemberVO;

@Service
public class MemberService implements IMemberService {
	@Autowired
	IMemberRepository memberRepository;
	
	// 회원가입
	@Override
	public int insertMember(MemberVO member) {
		return memberRepository.insertMember(member);
	}; 
	
	// id 중복확인
	@Override
	public String confirmId(String id) {
		return memberRepository.confirmId(id);
	};
	
	// 로그인
	@Override
	public int userCheck(String id,String pw) {
		return memberRepository.userCheck(id,pw);
	};
	
	// 회원 정보 가져오기
	@Override
	public MemberVO getMember(String id) {
		return memberRepository.getMember(id);
	};
	
	// 아이디 찾기
	@Override
	public String getUserId(String name, String email) {
		return memberRepository.getUserId(name,email);
	}; 
	
	// 비밀번호 변경 전 본인 확인
	@Override
	public String checkUserPw(String id, String name) {
		return memberRepository.checkUserPw(id,name);
	};
	
	// 비밀번호 변경
	@Override
	public int updatePw(String pw, String id) {
		return memberRepository.updatePw(pw,id);
	}; 
	
	// 회원 정보 수정
	@Override
	public int updateMember(MemberVO member) {
		return memberRepository.updateMember(member);
	}; 
	
	// 회원 탈퇴
	//public int withdrawMember(String id) {};
}
