package com.mzlife.app.member.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mzlife.app.member.model.MemberVO;
import com.mzlife.app.member.service.IMemberService;

@Controller
@RequestMapping(value="/member")
public class MemberController extends HttpServlet {
	
	@Autowired
	IMemberService memberService;
	
	@RequestMapping(value="/loginAction")
	public String userChekck(@RequestParam(value="loginId")String loginId,@RequestParam(value="loginPw")String loginPw,HttpSession session,Model model) {
		int ri = memberService.userCheck(loginId, loginPw);
		String result = null;
		
		model.addAttribute("ri", ri);
		if(ri == -1) {result = "아이디가 존재하지 않습니다."; model.addAttribute("result", result);}
		if(ri == 0) {result = "비밀번호가 일치하지 않습니다."; model.addAttribute("result", result);}
		if(ri == 1) {result = "로그인이 되었습니다.";session.setAttribute("id",loginId); return "/main";}
    	
    	return "member/login";
	}
	
	@RequestMapping(value="/idCheck")
	public String confirmId(@RequestParam(value="inputId")String userId,Model model) {
		String confirmId = memberService.confirmId(userId);
		model.addAttribute("passId",confirmId);
		return "member/join";
	}
	
	@RequestMapping(value="/joinAction")
	public String insertMember(MemberVO member) {
		int ri = memberService.insertMember(member);
		System.out.println("insert result : " + ri);
		
		if(ri==0) {return "member/join";}
		return "member/join_complete";
	}
	
	@RequestMapping(value="/logout")
	public String logoutConn(HttpSession session,HttpServletRequest request) {
		session = request.getSession();
		if(session != null && session.getAttribute("id") != null) {
			session.invalidate();
			return "/main";
		}
		return "/main";
	}
	
	@RequestMapping(value="/findId")
	public String getUserId(@RequestParam(value="userName")String userName,@RequestParam(value="userEmail")String userEmail,Model model) {
		String id = memberService.getUserId(userName, userEmail);
		if(id == null) {model.addAttribute("result","fail"); return "member/find_id";}
		if(id != null) {model.addAttribute("resultId",id); }
		return "member/find_id_result";
	}
	
	@RequestMapping(value="/checkUser")
	public String checkUserPw(@RequestParam(value="id")String id,@RequestParam(value="name")String name,Model model) {
		String userId = memberService.checkUserPw(id,name);
		model.addAttribute("id",userId);
		return "member/find_pw_change";
	}
	
	@RequestMapping(value="/changePw")
	public String updatePw(@RequestParam(value="newPw")String newPw, @RequestParam(value="id")String id) {
		int result = memberService.updatePw(newPw,id);
		System.out.println("pw change result : " + result);
		return "member/login";
	}
}
