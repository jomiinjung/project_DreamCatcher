package com.mzlife.app.sts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mzlife.app.sts.dao.IAnlysRepository;
import com.mzlife.app.sts.model.RatioVO;

@Service
public class LifeAnlysService implements ILifeAnlysService {
	
	@Autowired
	IAnlysRepository anlysRepository;
	
	@Override
	public List<RatioVO> getRatio(String ct){
		return anlysRepository.getRatio(ct);
	}
}
