package com.mzlife.app.sts.model;

public class CompScoreVO {

	private int economicStability;
	private int selfImprovement;
	private int exercise;
	private int leisure;
	private int relSocial;
	private int relFamily;
	
	public int getEconomicStability() {
		return economicStability;
	}
	public void setEconomicStability(int economicStability) {
		this.economicStability = economicStability;
	}
	public int getSelfImprovement() {
		return selfImprovement;
	}
	public void setSelfImprovement(int selfImprovement) {
		this.selfImprovement = selfImprovement;
	}
	public int getExercise() {
		return exercise;
	}
	public void setExercise(int exercise) {
		this.exercise = exercise;
	}
	public int getLeisure() {
		return leisure;
	}
	public void setLeisure(int leisure) {
		this.leisure = leisure;
	}
	public int getRelSocial() {
		return relSocial;
	}
	public void setRelSocial(int relSocial) {
		this.relSocial = relSocial;
	}
	public int getRelFamily() {
		return relFamily;
	}
	public void setRelFamily(int relFamily) {
		this.relFamily = relFamily;
	}
	
}
