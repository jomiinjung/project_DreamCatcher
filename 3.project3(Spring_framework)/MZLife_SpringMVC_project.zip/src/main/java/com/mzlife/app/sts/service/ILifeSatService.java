package com.mzlife.app.sts.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.app.sts.model.CompScoreVO;
import com.mzlife.app.sts.model.ConditionVO;
import com.mzlife.app.sts.model.FactorVO;
import com.mzlife.app.sts.model.RankFactorVO;

public interface ILifeSatService {
	String insertCondition(ConditionVO cond);
	void predictLifeSat(String tempId);
	ConditionVO getUserCond(String userId);
	ConditionVO conversionInfo(ConditionVO userInfo);
	FactorVO getFactor(String userId);
	RankFactorVO sortFactor(FactorVO factor);
	CompScoreVO getCompareScore(String userId);
}
