package com.mzlife.app.sts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.rosuda.REngine.Rserve.RConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.mzlife.app.sts.model.CompScoreVO;
import com.mzlife.app.sts.model.ConditionVO;
import com.mzlife.app.sts.model.FactorVO;
import com.mzlife.app.sts.model.RankFactorVO;

@Repository
public class ConditionRepository implements IConditionRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;

	private class CondMapper implements RowMapper<ConditionVO> {
		@Override
		public ConditionVO mapRow(ResultSet rs, int count) throws SQLException {
			ConditionVO cond = new ConditionVO();
			cond.setId(rs.getString("id"));
			cond.setName(rs.getString("name"));
			cond.setGender(rs.getString("gender"));
			cond.setBirth(rs.getInt("age"));
			cond.setEdu(rs.getString("edu"));
			cond.setEconomicStability(rs.getInt("economicStability"));
			cond.setSelfImprovement(rs.getInt("selfImprovement"));
			cond.setExercise(rs.getInt("exercise"));
			cond.setLeisure(rs.getInt("leisure"));
			cond.setRelSocial(rs.getInt("relSocial"));
			cond.setRelFamily(rs.getInt("relFamily"));
			cond.setSatLife(rs.getInt("satLife"));
			return cond;
		}
	}
	
	@Override
	public String insertCondition(ConditionVO cond) {
		// 사용자가 입력한 조건 db에 추가
		
		// 사용자에게 임의의 ID 부여하여 식별
		String id = cond.getId();
		if(id==null) {id = generateRandomId(10);}

		int birthYear = cond.getBirth();
		int currentYear = LocalDate.now().getYear();
		int userAge = currentYear - birthYear + 1;
		int userGender = Integer.parseInt(cond.getGender());
		int userEdu = Integer.parseInt(cond.getEdu());
		
		String sql = "insert into userlifecondition (id,name,age,gender,edu,economicStability,selfImprovement,exercise,leisure,relSocial,relFamily,satLife) "
					+"values (?,?,?,?,?,?,?,?,?,?,?,?)";
		jdbcTemplate.update(sql,
				id,
				cond.getName(),
				userAge,
				userGender,
				userEdu,
				cond.getEconomicStability(),
				cond.getSelfImprovement(),
				cond.getExercise(),
				cond.getLeisure(),
				cond.getRelSocial(),
				cond.getRelFamily(),
				cond.getSatLife());

		return id;
	}
	@Override
	public void predictLifeSat(String userId) {
		// r 연동해서 예측한 만족도 및 각 항목 별 계수 db에 insert

		// R 연동해서 회귀모델에 사용자 조건을 대입해 조건에 예상되는 만족도 산출
		RConnection rConn = null;
		
		try {
			// R 연동을 위해 Rserve 라이브러리 실행
			Process process = new ProcessBuilder("C:/Program Files/R/R-3.6.3/library/Rserve/libs/x64/Rserve.exe").start();
			// R과 연결
			rConn = new RConnection();
			rConn.eval("source('C:/mjspring/eGovFrameDev-3.9.0-64bit/workspace/mzlife_satisfaction_calc_num.R')");
			//rConn.eval("source('C:/eGovSpring/eGovFrameDev-3.9.0-64bit/workspace/mzlife_satisfaction_calc_num.R')");
			rConn.voidEval("library(Rserve)");
			rConn.voidEval("Rserve()");
			rConn.voidEval("library(RJDBC)");
			rConn.voidEval("jdbcDriver <- JDBC(driverClass = \"oracle.jdbc.driver.OracleDriver\",classPath = \"C:/oraclexe/app/oracle/product/11.2.0/server/jdbc/lib/ojdbc6.jar\")");
			rConn.voidEval("con <- dbConnect(jdbcDriver,\"jdbc:oracle:thin:@localhost:1521:xe\",\"scott\",\"tiger\")");
			
			// R에 사용자 id 전달해서 삶의 만족도 예측한 후 DB에 업데이트
			rConn.voidEval("calcLifeSat('" + userId + "')");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rConn != null) {
				rConn.close();
			}
		}
	}

	@Override
	public ConditionVO getUserCond(String userId) {
		String sql = "select id,name,age,gender,edu,economicStability,selfImprovement,exercise,leisure,relSocial,relFamily,satLife from userlifecondition where id=?";
		try {
			return jdbcTemplate.queryForObject(sql, new CondMapper(),userId);
		}catch (IncorrectResultSizeDataAccessException error) {
			return null;
		}
		
	}

	// 같은 조건을 가진 그룹의 평균점수 가져오기
	@Override
	public CompScoreVO getCompareScore(String userId) {
		CompScoreVO scores = null;
		String sql = "select avgstability,avgimprovment,avgexercise,avgleisure,avgrelsocial,avgrelfamily from comparescore where id=?";
		scores = jdbcTemplate.queryForObject(sql, new RowMapper<CompScoreVO>() {
			@Override
			public CompScoreVO mapRow(ResultSet rs, int count) throws SQLException{
				CompScoreVO score = new CompScoreVO();
				score.setEconomicStability(rs.getInt("avgstability"));
				score.setSelfImprovement(rs.getInt("avgimprovment"));
				score.setExercise(rs.getInt("avgexercise"));
				score.setLeisure(rs.getInt("avgleisure"));
				score.setRelSocial(rs.getInt("avgrelsocial"));
				score.setRelFamily(rs.getInt("avgrelfamily"));
				return score;
			}
		},userId);
		
		return scores;
	}
	
	@Override
	// 분석 결과 예측 만족도, 요인별 가중치 가져오기
	public FactorVO getFactor(String userId) {

		FactorVO factor = null;
		ArrayList<Integer> weights = new ArrayList<>();
		
		String sql = "select * from analyzedfactor where id=?";
		
		try {
			
			factor = jdbcTemplate.queryForObject(sql,new RowMapper<FactorVO>(){
				@Override
				public FactorVO mapRow(ResultSet rs, int count) throws SQLException{

					weights.add(rs.getInt("economicStability"));
					weights.add(rs.getInt("selfImprovement"));
					weights.add(rs.getInt("exercise"));
					weights.add(rs.getInt("leisure"));
					weights.add(rs.getInt("relSocial"));
					weights.add(rs.getInt("relFamily"));
					
					for(int i = 0; i< weights.size();i++) {
						if(weights.get(i)>100) {weights.set(i,100);}
						if(weights.get(i)<0) {weights.set(i,0);}
					}
					
					FactorVO factorRs = new FactorVO();
					factorRs.setId(rs.getString("id"));
					factorRs.setPredSatLife(rs.getInt("predictedSatLife"));
					factorRs.setEconomicStability(weights.get(0));
					factorRs.setSelfImprovement(weights.get(1));
					factorRs.setExercise(weights.get(2));
					factorRs.setLeisure(weights.get(3));
					factorRs.setRelSocial(weights.get(4));
					factorRs.setRelFamily(weights.get(5));
					return factorRs;
				}
			},userId);

			return factor;
		}catch (IncorrectResultSizeDataAccessException error) {
			return null;
		}
		
	}

	@Override
	// 요인별 가중치 상위 3개
	public RankFactorVO sortFactor(FactorVO factor) {
		// 영향을 주는 factor들을 순위별로 정렬

		RankFactorVO rank = null;
		Map<String,Integer> factorItem = new HashMap<>();
		// 항목, 값 map에 저장
		factorItem.put("경제적 안정성", factor.getEconomicStability());
		factorItem.put("자기계발 활동", factor.getSelfImprovement());
		factorItem.put("신체적 활동", factor.getExercise());
		factorItem.put("여가활동", factor.getLeisure());
		factorItem.put("사회적 관계", factor.getRelSocial());
		factorItem.put("가족관계", factor.getRelFamily());
		
		rank = new RankFactorVO();
		List<Map.Entry<String, Integer>> entryList = new LinkedList<>(factorItem.entrySet());
		entryList.sort(((o1, o2) -> factorItem.get(o2.getKey()) - factorItem.get(o1.getKey())));
		rank.setFirstClass(entryList.get(0));
		rank.setSecondClass(entryList.get(1));
		rank.setThirdClass(entryList.get(2));

		return rank;
	}

	@Override
	// 성별, 학력 문자로 conversion
	public ConditionVO conversionInfo(ConditionVO cond) {
		String gender = cond.getGender();
		String edu = cond.getEdu();
		int age = cond.getBirth();
		
		// gender
		if (gender.equals("1")) {cond.setGender("남자");} 
		if (gender.equals("2")) {cond.setGender("여자");}
		// edu
		if (edu.equals("1")) {cond.setEdu("고등학교 졸업 미만");} 
		if (edu.equals("2")) {cond.setEdu("고등학교 졸업");} 
		if (edu.equals("3")) {cond.setEdu("대학 재학 또는 중퇴");} 
		if (edu.equals("4")) {cond.setEdu("전문대학 졸업");} 
		if (edu.equals("5")) {cond.setEdu("4년제 대학 졸업");}
		if (edu.equals("6")) {cond.setEdu("대학원 재학 또는 졸업");}
		
		return cond;
	}

	public String generateRandomId(int length) {
		// 비회원 : 랜덤 아이디 생성
		String characters = "0123456789abcdefghijklmnopqrstuvwxyz";
		StringBuilder randomString = new StringBuilder();
		Set<Character> uniqueChars = new HashSet<>();

		Random random = new Random();
		while (randomString.length() < length) {
			char randomChar = characters.charAt(random.nextInt(characters.length()));
			if (uniqueChars.add(randomChar)) {
				randomString.append(randomChar);
			}
		}

		return randomString.toString();
	}

}
