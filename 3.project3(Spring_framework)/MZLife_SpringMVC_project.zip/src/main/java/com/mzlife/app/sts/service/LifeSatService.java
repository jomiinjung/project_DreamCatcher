package com.mzlife.app.sts.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mzlife.app.sts.dao.IConditionRepository;
import com.mzlife.app.sts.model.CompScoreVO;
import com.mzlife.app.sts.model.ConditionVO;
import com.mzlife.app.sts.model.FactorVO;
import com.mzlife.app.sts.model.RankFactorVO;

@Service
public class LifeSatService implements ILifeSatService {

	@Autowired
	IConditionRepository condRepository;
	
	@Override
	public String insertCondition(ConditionVO cond) {
		String userId = condRepository.insertCondition(cond);
		return userId;
	}
	
	@Override
	public void predictLifeSat(String userId) {
		condRepository.predictLifeSat(userId);
	}

	@Override
	public ConditionVO getUserCond(String userId) {
		return condRepository.getUserCond(userId);
	}

	@Override
	public ConditionVO conversionInfo(ConditionVO userInfo) {
		return condRepository.conversionInfo(userInfo);
	}
	
	@Override
	public FactorVO getFactor(String userId){
		return condRepository.getFactor(userId);
	}
	
	@Override
	public RankFactorVO sortFactor(FactorVO factor){
		return condRepository.sortFactor(factor);
	}
	
	@Override
	public CompScoreVO getCompareScore(String userId) {
		return condRepository.getCompareScore(userId);
	}
	
}
