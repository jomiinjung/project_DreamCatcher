package com.mzlife.app.sts.service;

import java.util.List;
import com.mzlife.app.sts.model.RatioVO;

public interface ILifeAnlysService {
	public List<RatioVO> getRatio(String ct);
}
