package com.mzlife.app.sts.model;

public class FactorVO { 
	// 예측 만족도와 항목별 가중치
	private String id;
	private int predSatLife;
	private int economicStability;
	private int selfImprovement;
	private int exercise;
	private int leisure;
	private int relSocial;
	private int relFamily;
	
	public FactorVO() {};
	public FactorVO(String id, int predSatLife,int economicStability,int selfImprovement,int exercise,int leisure,int relSocial,int relFamily){
		this.id=id;
		this.predSatLife=predSatLife;
		this.economicStability=economicStability;
		this.selfImprovement=selfImprovement;
		this.exercise=exercise;
		this.leisure=leisure;
		this.relSocial=relSocial;
		this.relFamily=relFamily;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPredSatLife() {
		return predSatLife;
	}
	public void setPredSatLife(int predSatLife) {
		this.predSatLife = predSatLife;
	}
	public int getEconomicStability() {
		return economicStability;
	}
	public void setEconomicStability(int economicStability) {
		this.economicStability = economicStability;
	}
	public int getSelfImprovement() {
		return selfImprovement;
	}
	public void setSelfImprovement(int selfImprovement) {
		this.selfImprovement = selfImprovement;
	}
	public int getExercise() {
		return exercise;
	}
	public void setExercise(int exercise) {
		this.exercise = exercise;
	}
	public int getLeisure() {
		return leisure;
	}
	public void setLeisure(int leisure) {
		this.leisure = leisure;
	}
	public int getRelSocial() {
		return relSocial;
	}
	public void setRelSocial(int relSocial) {
		this.relSocial = relSocial;
	}
	public int getRelFamily() {
		return relFamily;
	}
	public void setRelFamily(int relFamily) {
		this.relFamily = relFamily;
	}
	
	
}
