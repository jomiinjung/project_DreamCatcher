
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class SmartPhone {
	Scanner in = new Scanner(System.in);
	Map<String,Addr> addrMap = new HashMap<>();
	Set<Map.Entry<String,Addr>> entrySet = addrMap.entrySet();
	Iterator<Map.Entry<String,Addr>> entryIterator;
	Map.Entry<String,Addr> entry;
	// 등록
	public Addr inputAddrData() {
		System.out.print("이름 : ");
		String name = in.nextLine();
		System.out.print("전화번호 : ");
		String phnNum = in.nextLine();
		System.out.print("이메일 : ");
		String email = in.nextLine();
		System.out.print("주소 : ");
		String addr = in.nextLine();
		System.out.print("그룹(친구/가족) : ");
		String group = in.nextLine();
		return new Addr(name,phnNum,email,addr,group);
	}

	public void addAddr(Addr addr) {
		addrMap.put(addr.getPhnNum(),addr);
	}
	
	public void entryItr () {
		entryIterator = entrySet.iterator();
	}
	public Addr getAddr() {
		entry = entryIterator.next();
		return entry.getValue();
	}
	
	// 출력
	public void printAddr(Addr addr) {
		System.out.println("---------------------------------");
		System.out.println("이름 : "+addr.getName());
		System.out.println("전화번호 : "+addr.getPhnNum());
		System.out.println("이메일 : "+addr.getEmail());
		System.out.println("주소 : "+addr.getAddr());
		System.out.println("그룹 : "+addr.getGroup());
		System.out.println("---------------------------------");
	}

	public void printAllAddr() {
		while(entryIterator.hasNext()) {
			entry = entryIterator.next();
			printAddr(entry.getValue());
		}
		System.out.println("객체 수"+addrMap.size());
	}
	
	// 검색
	public void searchAddr(String name) {
		while(entryIterator.hasNext()) {
			entry = entryIterator.next();
			Addr addr = entry.getValue();
			if(addr.getName().equals(name)) {
				printAddr(addr);
				return;
			}
		}
	}
	
	// 삭제
	public void deleteAddr(String name) {
		while(entryIterator.hasNext()) {
			entry = entryIterator.next();
			Addr addr = entry.getValue();
			if(addr.getName().equals(name)) {
				addrMap.remove(addr.getPhnNum());
				System.out.println("삭제 되었습니다.");
				return;
			}
		}
	}
	
	// 수정
	public void editAddr(String name,Addr newAddr) {
		while(entryIterator.hasNext()) {
			entry = entryIterator.next();
			Addr addr = entry.getValue();
			if(addr.getName().equals(name)) {
				addrMap.remove(addr.getPhnNum());
				addrMap.put(newAddr.getPhnNum(),newAddr);
				System.out.println("수정 되었습니다.");
				return;
			}
		}
	}
	

}
