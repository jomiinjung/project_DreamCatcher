
public class Main {

	public static void main(String[] args) {
		SonataLowGrade sonataLowGrade = new SonataLowGrade();
		SonataHighGrade sonataHighGrade = new SonataHighGrade();

		sonataLowGrade.getSpec();
		sonataHighGrade.getSpec();

	}

}
