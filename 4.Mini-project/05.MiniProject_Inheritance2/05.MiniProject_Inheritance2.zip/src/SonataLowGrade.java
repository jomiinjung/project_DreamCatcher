
public class SonataLowGrade extends Sonata {
	int tax;
	public SonataLowGrade() {}
	public SonataLowGrade(String color,String tire,int displacement,String handle){
		super(color,tire,displacement,handle);
	}
	
	@Override
	public void getSpec() {
		color = CarSpecs.COLOR_BLUE;
		tire = CarSpecs.TIRE_NORMAL;
		displacement = CarSpecs.LOW_DISPLACEMENT;
		handle = CarSpecs.HANDLE_POWER;
		tax = 1000;
		
		System.out.println("********************");
		System.out.println("색상 : "+color);
		System.out.println("타이어 : "+tire);
		System.out.println("배기량 : "+displacement);
		System.out.println("핸들 : "+handle);
		System.out.println("세금 : "+tax);
		System.out.println("********************");
	}
}
