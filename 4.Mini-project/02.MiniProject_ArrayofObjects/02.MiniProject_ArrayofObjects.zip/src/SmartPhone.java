import java.util.Scanner;

public class SmartPhone {
	Scanner in = new Scanner(System.in);
	Addr[] addr = new Addr[10];
	int count = 0;
	
	public Addr inputAddrData() {
		System.out.println("이름 : ");
		String name = in.nextLine();
		System.out.println("전화번호 : ");
		String phnNum = in.nextLine();
		System.out.println("이메일 : ");
		String email = in.nextLine();
		System.out.println("주소 : ");
		String addr = in.nextLine();
		System.out.println("그룹(친구/가족) : ");
		String group = in.nextLine();
		return new Addr(name,phnNum,email,addr,group);
	}
	
	public void addAddr(Addr Addr) {
		addr[count] = Addr;
		count++;
		System.out.println(">>> 데이터가 저장되었습니다.("+count+")");
	}
	
	public void printAddr(Addr Addr) {
		System.out.println("---------------------------------");
		System.out.println("이름 : "+Addr.getName());
		System.out.println("전화번호 : "+Addr.getPhnNum());
		System.out.println("이메일 : "+Addr.getEmail());
		System.out.println("주소 : "+Addr.getAddr());
		System.out.println("그룹 : "+Addr.getGroup());
		System.out.println("---------------------------------");
	}

	public void printAllAddr() {
		for(int i=0;i<count;++i) {
			printAddr(addr[i]);
		}
	}

	public void searchAddr(String name) {
		for(int i=0;i<count;++i) {
			if(addr[i].getName().contentEquals(name)) {
				printAddr(addr[i]);
				return; 
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}
	
	public void deleteAddr(String name) {
		for(int i=0;i<count;++i) {
			if(this.addr[i].getName().contentEquals(name)) {
				for(int j=i;j<count;++j) {
					addr[j] = addr[j+1];
				}
				count--;
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}
	
	public void editAddr(String name, Addr newAddr) {
		for(int i=0;i<count;++i) {
			if(this.addr[i].getName().contentEquals(name)) {
				addr[i]= newAddr;
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}
}
