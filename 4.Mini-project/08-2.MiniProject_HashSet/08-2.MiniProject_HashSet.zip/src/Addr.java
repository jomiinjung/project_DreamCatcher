
public class Addr {
	private String name;
	private String phnNum;
	private String email;
	private String addr;
	private String group;
	
	Addr(String name,String phnNum,String email,String addr,String group){
		this.name = name;
		this.phnNum = phnNum;
		this.email = email;
		this.addr = addr;
		this.group = group;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getPhnNum() {
		return phnNum;
	}
	public void setPhnNum(String phnNum) {
		this.phnNum = phnNum;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Addr) {
			Addr addr = (Addr)obj;
			return addr.getName().equals(getName()) && addr.getPhnNum().equals(getPhnNum()) && addr.getEmail().equals(getEmail()) && addr.getAddr().equals(getAddr()) && addr.getGroup().equals(getGroup());
		}else {
			return false;
		}
	}
	@Override
	public int hashCode() {
		return name.hashCode() + phnNum.hashCode() + email.hashCode() + addr.hashCode() + group.hashCode();
	}
}
