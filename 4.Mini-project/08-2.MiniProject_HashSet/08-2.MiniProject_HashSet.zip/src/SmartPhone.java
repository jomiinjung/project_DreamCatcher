import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class SmartPhone {
	Scanner in = new Scanner(System.in);
	Set<Addr> addrSet = new HashSet<Addr>();
	Iterator<Addr> iterator;
	// 등록
	public Addr inputAddrData() {
		System.out.print("이름 : ");
		String name = in.nextLine();
		System.out.print("전화번호 : ");
		String phnNum = in.nextLine();
		System.out.print("이메일 : ");
		String email = in.nextLine();
		System.out.print("주소 : ");
		String addr = in.nextLine();
		System.out.print("그룹(친구/가족) : ");
		String group = in.nextLine();
		return new Addr(name,phnNum,email,addr,group);
	}

	public void addAddr(Addr addr) {
		addrSet.add(addr);
	}
	
	public void renewIterator() {
		iterator = addrSet.iterator();
	}
	
	// 출력
	public void printAddr(Addr addr) {
		System.out.println("---------------------------------");
		System.out.println("이름 : "+addr.getName());
		System.out.println("전화번호 : "+addr.getPhnNum());
		System.out.println("이메일 : "+addr.getEmail());
		System.out.println("주소 : "+addr.getAddr());
		System.out.println("그룹 : "+addr.getGroup());
		System.out.println("---------------------------------");
	}

	public void printAllAddr() {
		while(iterator.hasNext()) {
			printAddr(iterator.next());
		}
	}
	
	// 검색
	public void searchAddr(String name) {
		while(iterator.hasNext()) {
			Addr addr = iterator.next();
			if(addr.getName().equals(name)) {
				printAddr(addr);
				return;
			}
		}
	}
	
	// 삭제
	public void deleteAddr(String name) {
		while(iterator.hasNext()) {
			Addr addr = iterator.next();
			if(addr.getName().equals(name)) {
				iterator.remove();
				System.out.println("삭제 되었습니다.");
				return;
			}
		}
	}
	
	// 수정
	public void editAddr(String name,Addr newAddr) {
		while(iterator.hasNext()) {
			Addr addr = iterator.next();
			if(addr.getName().equals(name)) {
				iterator.remove();
				addAddr(newAddr);
				System.out.println("수정 되었습니다.");
				return;
			}
		}
	}
	

}
