
import java.util.*;

public class NumberTest {
	public static void main(String[] args) {
		NumberTest numberTest = new NumberTest();
		System.out.println("출생연도를 입력해주세요.");
		Scanner in = new Scanner(System.in);
		try {
			checkNumber(in.nextLine());
//			numberTest.equals(birthYear);
		} catch(InputException e){
			String message = e.getMessage();
			System.out.println(message);
			e.printStackTrace();
		}
	}
	
	public static boolean checkNumber(String birthYear) throws InputException{
		boolean isTrue;
		if(true) {
			int d = Integer.parseInt(birthYear);
			throw new InputException("입력하신 데이터는 숫자가 아닙니다");
		}
		return false;
	}

}
