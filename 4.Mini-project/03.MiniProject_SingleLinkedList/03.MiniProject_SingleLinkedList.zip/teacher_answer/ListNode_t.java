public class ListNode_t {
	private String data;
	public ListNode link;

	public ListNode_t() {
		this.data = null;
		this.link = null;
	}

	public ListNode_t(String data) {
		this.data = data;
		this.link = null;
	}

	public ListNode_t(String data, ListNode link) {
		this.data = data;
	}

	public String getData() {
		return this.data;
	}
}