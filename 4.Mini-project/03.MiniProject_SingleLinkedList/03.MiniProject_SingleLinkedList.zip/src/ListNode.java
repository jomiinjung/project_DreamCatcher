
public class ListNode {
	private String data;
	public ListNode link;
	
	ListNode(){
		this.data = null;
		this.link = null;
	}
	ListNode(String data){
		this.data = data;
		this.link = null;
	}
	ListNode(String data,ListNode link){
		this.data = data;
	}
	
	public String getData() {
		return this.data;
	}
	public void setData(String data) {
		this.data = data;
	}
}
