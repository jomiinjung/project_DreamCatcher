
public class LinkedList {
	private ListNode head;
	ListNode preNode;
	
	LinkedList(){
		head = null;
	}

	public ListNode getHead() {
		return head;
	}

	public void setHead(ListNode head) {
		this.head = head;
	}
	
	public void insertMiddleNode(ListNode pre,String data) {
		ListNode newNode = new ListNode(data);
		newNode.link = pre.link;
		pre.link = newNode;
	}
	
	public void insertLastNode(String data) {
		if(this.head!=null) {
			ListNode temp = preNode;
			temp.link = new ListNode(data);
			preNode = temp.link;
		}else {
			this.head = new ListNode(data);
			preNode = this.head;
		}
	}
	
	public void deleteLastNode() {
		ListNode pre, temp;
		temp = this.head;
		while (temp != null) {
			pre = temp;
			temp = temp.link;
			if(temp.link==null) {
				pre.link = null;
				return;
			}
		}
	}
	
	public ListNode searchNode(String data) {
		ListNode temp = this.head;
		
		while (temp != null) {
			if(temp.getData()==data) {
				return temp;
			}
			temp = temp.link;
		}

		return null;
	}
	
	public void reverseList() {
		ListNode next = head; // 1
		ListNode current = null;
		ListNode pre = null;
		
		current = next.link;
		pre = current.link;
		head=pre.link;
		head.link = pre;
		pre.link = current;
		current.link = next;
		next.link = null;
	}
	

	public void printList() {
		ListNode temp = this.head;
		System.out.printf("L = (");
		while (temp != null) {
			System.out.printf(temp.getData());
			temp = temp.link;
			if(temp != null) {
				System.out.printf(", ");
			}
		}
		System.out.printf(")\n");
	}
	

}
