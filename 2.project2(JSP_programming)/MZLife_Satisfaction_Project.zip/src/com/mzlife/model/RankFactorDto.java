package com.mzlife.model;

import java.util.Map;

public class RankFactorDto {
	 private Map.Entry<String, Integer> firstClass;
	 private Map.Entry<String, Integer> secondClass;
	 private Map.Entry<String, Integer> thirdClass;
	public Map.Entry<String, Integer> getFirstClass() {
		return firstClass;
	}
	public void setFirstClass(Map.Entry<String, Integer> firstClass) {
		this.firstClass = firstClass;
	}
	public Map.Entry<String, Integer> getSecondClass() {
		return secondClass;
	}
	public void setSecondClass(Map.Entry<String, Integer> secondClass) {
		this.secondClass = secondClass;
	}
	public Map.Entry<String, Integer> getThirdClass() {
		return thirdClass;
	}
	public void setThirdClass(Map.Entry<String, Integer> thirdClass) {
		this.thirdClass = thirdClass;
	}
	 
}
