package com.mzlife.model;

public class ConditionDto {
	private String id;
	private String name;
	private int birth;
	private String gender;
	private String edu;
	private int economicStability;
	private int selfImprovement;
	private int exercise;
	private int leisure;
	private int relSocial;
	private int relFamily;
	private int satLife;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBirth() {
		return birth;
	}
	public void setBirth(int birth) {
		this.birth = birth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEdu() {
		return edu;
	}
	public void setEdu(String edu) {
		this.edu = edu;
	}
	public int getEconomicStability() {
		return economicStability;
	}
	public void setEconomicStability(int economicStability) {
		this.economicStability = economicStability;
	}
	public int getSelfImprovement() {
		return selfImprovement;
	}
	public void setSelfImprovement(int selfImprovement) {
		this.selfImprovement = selfImprovement;
	}
	public int getExercise() {
		return exercise;
	}
	public void setExercise(int exercise) {
		this.exercise = exercise;
	}
	public int getLeisure() {
		return leisure;
	}
	public void setLeisure(int leisure) {
		this.leisure = leisure;
	}
	public int getRelSocial() {
		return relSocial;
	}
	public void setRelSocial(int relSocial) {
		this.relSocial = relSocial;
	}
	public int getRelFamily() {
		return relFamily;
	}
	public void setRelFamily(int relFamily) {
		this.relFamily = relFamily;
	}
	public int getSatLife() {
		return satLife;
	}
	public void setSatLife(int satLife) {
		this.satLife = satLife;
	}
	

}
