package com.mzlife.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDao {
	public static final int MEMBER_JOIN_FAIL = 0;
	public static final int MEMBER_JOIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_PW_NO_GOOD = 0;
	public static final int MEMBER_LOGIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_IS_NOT = -1;

	private static MemberDao instance = new MemberDao();
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	DataSource dataSource;
	ResultSet resultSet = null;
	
	private MemberDao() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/Oracle11g");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static MemberDao getInstance() {
		return instance;
	}
	
	// 회원가입
	public int insertMember(MemberDto member) {
		int ri = 0;
		String query = "insert into users (id, password, name, email, phone, agree, validity)"
				+" values (?,?,?,?,?,?,?)";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, member.getUserId());
			pstmt.setString(2, member.getUserPw());
			pstmt.setString(3, member.getUserName());
			pstmt.setString(4, member.getUserEmail());
			pstmt.setInt(5, member.getUserTel());
			pstmt.setString(6, member.getAgree());
			pstmt.setString(7, member.getValidity());

			pstmt.executeUpdate();
			ri = MemberDao.MEMBER_JOIN_SUCCESS;
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ri;
	}
	
	// id 중복확인
	public String confirmId(String id) {
		String possibleId = null;
		String query = "select id from users where id=?";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, id);

			resultSet = pstmt.executeQuery();
			if(resultSet.next()) {
				possibleId = "exist";
			}else {
				possibleId = id;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return possibleId;
	}
	
	// 로그인
	public int userCheck(String id,String pw) {
		int ri = 0;
		String dbPw;
		String query = "select password from users where id=?";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, id);

			resultSet = pstmt.executeQuery();
			if(resultSet.next()) {
				dbPw = resultSet.getString("password");
				if(pw.equals(dbPw)) {
					ri = MemberDao.MEMBER_LOGIN_SUCCESS;
				}else {
					ri = MemberDao.MEMBER_LOGIN_PW_NO_GOOD;
				}
			}else {
				ri = MemberDao.MEMBER_LOGIN_IS_NOT;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ri;
	}
	
	// 회원 정보 가져오기
	public MemberDto getMember(String id) {
		MemberDto member = null;
		String query = "select * from users where id=?";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, id);

			resultSet = pstmt.executeQuery();
			if(resultSet.next()) {
				member = new MemberDto();
				member.setUserId(resultSet.getString("id"));
				member.setUserPw(resultSet.getString("password"));
				member.setUserName(resultSet.getString("name"));
				member.setUserEmail(resultSet.getString("phone"));
				member.setUserTel(resultSet.getInt("email"));
				member.setAgree(resultSet.getString("agree"));
				member.setValidity(resultSet.getString("valirity"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return member;
	}
	
	// 아이디 찾기
	public String getUserId(String name, String email) {
		String id = null;
		String query = "select id from users where name=? and email=?";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setString(2, email);

			resultSet = pstmt.executeQuery();
			if(resultSet.next()) {
				id = resultSet.getString("id");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return id;
	}

	// 비밀번호 변경 전 본인 확인
	public String checkUserPw(String id, String name) {
		String checkedId = null;
		String query = "select id from users where name=? and id=?";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setString(2, id);

			resultSet = pstmt.executeQuery();
			if(resultSet.next()) {
				checkedId = resultSet.getString("id");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return checkedId;
	}
	
	
	// 비밀번호 변경
	public int updatePw(String pw, String id) {
		int ri = 0;
		String query = "update users set password= ? where id= ?";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, pw);
			pstmt.setString(2, id);

			ri = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ri;
	}
	
	// 회원 정보 수정
	public int updateMember(MemberDto member) {
		int ri = 0;
		String query = "update users set password= ?, email= ?, phone= ? where id= ?";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, member.getUserPw());
			pstmt.setString(2, member.getUserEmail());
			pstmt.setInt(3, member.getUserTel());
			pstmt.setString(4, member.getUserId());

			ri = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ri;
	}
	
	// 회원 탈퇴
	//public int withdrawMember(String id){}; 
}
