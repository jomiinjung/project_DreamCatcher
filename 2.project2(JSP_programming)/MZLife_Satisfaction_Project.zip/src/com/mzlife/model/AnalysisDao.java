package com.mzlife.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.rosuda.REngine.Rserve.RConnection;

public class AnalysisDao {
	private static AnalysisDao instance = new AnalysisDao();

	// getInstance
	public static AnalysisDao getInstance() {
		return instance;
	}

	Connection conn = null;
	PreparedStatement pstmt = null;
	DataSource dataSource;
	ResultSet resultSet = null;

	RConnection rConn = null;

	public AnalysisDao() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/Oracle11g");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public ArrayList<RatioDto> getRatio(String ct) {
		ArrayList<RatioDto> result = new ArrayList<>();
		ArrayList<Integer> satLife;
		ArrayList<Integer> satLeisure;
		ArrayList<Integer> satJob;
		ArrayList<Integer> working;
		ArrayList<Integer> marriage;
		ArrayList<Integer> employType;
		String criteria;
		String criteriaItem;
		int wage;
		int workingHour;
		
		try {
			conn = dataSource.getConnection();

			String query = "select * from statdatas where criteria=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, ct);
			resultSet = pstmt.executeQuery();
			
			while(resultSet.next()) {
				// 선택 기준
				criteria = resultSet.getString("criteria");
				criteriaItem = resultSet.getString("criteriaVal");
				
				// 삶의 만족도
				satLife = new ArrayList<>();
				for(int i = 1; i<=5; i++) {
					satLife.add(resultSet.getInt("life_"+i));
				}
				// 여가생활 만족도
				satLeisure = new ArrayList<>();
				for(int i = 1; i<=5; i++) {
					satLeisure.add(resultSet.getInt("leisure_"+i));
				}
				// 직무 만족도
				satJob = new ArrayList<>();
				for(int i=1; i<=5; i++) {
					satJob.add(resultSet.getInt("job_"+i));
				}
				// 취업여부
				working = new ArrayList<>();
				working.add(resultSet.getInt("working_y"));
				working.add(resultSet.getInt("working_n"));
				// 혼인여부
				marriage = new ArrayList<>();
				marriage.add(resultSet.getInt("marriage_n"));
				marriage.add(resultSet.getInt("marriage_y"));
				// 고용형태(정규직/비정규직)
				employType = new ArrayList<>();
				employType.add(resultSet.getInt("rglworker_y"));
				employType.add(resultSet.getInt("rglworker_n"));
				
				wage = resultSet.getInt("wage_avg");
				workingHour = resultSet.getInt("workinghour_avg");
				
				RatioDto ratio = null;
				if(criteria.equals("life_satisfaction")) {
					// 삶의 만족도를 기준으로 그래프 생성 시 삶의 만족도는 null
					ratio = new RatioDto(criteria,criteriaItem,null,satLeisure,satJob,working,marriage,employType,wage,workingHour);
				}else if(criteria.equals("working")) {
					// 취업여부 기준으로 그래프 생성 시 직무만족도, 취업여부, 고용형태, 임금, 근무시간 null
					ratio = new RatioDto(criteria,criteriaItem,satLife,satLeisure,null,null,marriage,null,0,0);
				}else {
					ratio = new RatioDto(criteria,criteriaItem,satLife,satLeisure,satJob,working,marriage,employType,wage,workingHour);
				}
				result.add(ratio);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
				if (resultSet != null)
					resultSet.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return result;
	}
	
}
