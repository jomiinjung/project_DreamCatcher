package com.mzlife.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.rosuda.REngine.Rserve.RConnection;


public class ConditionDao {
	private static ConditionDao instance = new ConditionDao();

	// getInstance
	public static ConditionDao getInstance() {
		return instance;
	}

	Connection conn = null;
	PreparedStatement pstmt = null;
	DataSource dataSource;
	ResultSet resultSet = null;

	HttpSession session = null;
	RConnection rConn = null;

	public ConditionDao() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/Oracle11g");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 사용자 입력 정보 db에 insert
	public String insertCondition(ConditionDto cond) {
		String id = cond.getId();
		if(id==null) {id = generateRandomId(10);}
		
		int birthYear = cond.getBirth();
		int currentYear = LocalDate.now().getYear();
		int userAge = currentYear - birthYear + 1;
		int userGender = Integer.parseInt(cond.getGender());
		int userEdu = Integer.parseInt(cond.getEdu());
		
		try {
			conn = dataSource.getConnection();
			String query = "insert into userlifecondition (id,name,age,gender,edu,economicStability,selfImprovement,exercise,leisure,relSocial,relFamily,satLife) values (?,?,?,?,?,?,?,?,?,?,?,?)";

			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, id);
			pstmt.setString(2, cond.getName());
			pstmt.setInt(3, userAge);
			pstmt.setInt(4, userGender);
			pstmt.setInt(5, userEdu);
			pstmt.setInt(6, cond.getEconomicStability());
			pstmt.setInt(7, cond.getSelfImprovement());
			pstmt.setInt(8, cond.getExercise());
			pstmt.setInt(9, cond.getLeisure());
			pstmt.setInt(10, cond.getRelSocial());
			pstmt.setInt(11, cond.getRelFamily());
			pstmt.setInt(12, cond.getSatLife());

			int rn = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return id;
	}
	
	// r 연동해서 예측한 만족도 및 각 항목 별 계수 db에 insert
	public void predictLifeSat(String userId) {
		
		// R 연동해서 회귀모델에 사용자 조건을 대입해 조건에 예상되는 만족도 산출
		RConnection rConn = null;
		
		try {
			// R 연동을 위해 Rserve 라이브러리 실행
			Process process = new ProcessBuilder("C:/Program Files/R/R-3.6.3/library/Rserve/libs/x64/Rserve.exe").start();
			// R과 연결
			rConn = new RConnection();
			rConn.eval("source('C:/mjspring/eGovFrameDev-3.9.0-64bit/workspace/mzlife_satisfaction_calc_num.R')");
			//rConn.eval("source('C:/eGovSpring/eGovFrameDev-3.9.0-64bit/workspace/mzlife_satisfaction_calc_num.R')");
			rConn.voidEval("library(Rserve)");
			rConn.voidEval("Rserve()");
			rConn.voidEval("library(RJDBC)");
			rConn.voidEval("jdbcDriver <- JDBC(driverClass = \"oracle.jdbc.driver.OracleDriver\",classPath = \"C:/oraclexe/app/oracle/product/11.2.0/server/jdbc/lib/ojdbc6.jar\")");
			rConn.voidEval("con <- dbConnect(jdbcDriver,\"jdbc:oracle:thin:@localhost:1521:xe\",\"scott\",\"tiger\")");
			
			// R에 사용자 id 전달해서 삶의 만족도 예측한 후 DB에 업데이트
			rConn.voidEval("calcLifeSat('" + userId + "')");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rConn != null) {
				rConn.close();
			}
		}
	}
	
	// 사용자가 입력한 정보 가져오기
	public ConditionDto getUserCond(String userId) {
		ConditionDto dto = null;
		try {
			conn = dataSource.getConnection();
			String query = "select * from userlifecondition where id=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, userId);

			resultSet = pstmt.executeQuery();
			
			while(resultSet.next()) {
				dto = new ConditionDto(); 
				dto.setId(resultSet.getString("id"));
				dto.setName(resultSet.getString("name"));
				dto.setBirth(resultSet.getInt("age"));
				dto.setGender(resultSet.getString("gender"));
				dto.setEdu(resultSet.getString("edu"));
				dto.setEconomicStability(resultSet.getInt("economicStability"));
				dto.setSelfImprovement(resultSet.getInt("selfImprovement"));
				dto.setExercise(resultSet.getInt("exercise"));
				dto.setLeisure(resultSet.getInt("leisure"));
				dto.setRelSocial(resultSet.getInt("relSocial"));
				dto.setRelFamily(resultSet.getInt("relFamily"));
				dto.setSatLife(resultSet.getInt("satLife"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	
	// 같은 조건을 가진 그룹의 평균점수 가져오기
	public CompScoreDto getCompareScore(String userId) {
		CompScoreDto dto = null;
		try {
			conn = dataSource.getConnection();
			String query = "select * from comparescore where id=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, userId);

			resultSet = pstmt.executeQuery();
			
			while(resultSet.next()) {
				dto = new CompScoreDto(); 
				dto.setEconomicStability(resultSet.getInt("avgstability"));
				dto.setSelfImprovement(resultSet.getInt("avgimprovment"));
				dto.setExercise(resultSet.getInt("avgexercise"));
				dto.setLeisure(resultSet.getInt("avgleisure"));
				dto.setRelSocial(resultSet.getInt("avgrelsocial"));
				dto.setRelFamily(resultSet.getInt("avgrelfamily"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	
	// 분석 결과 예측 만족도, 요인별 가중치 가져오기
	public FactorDto getFactor(String userId) {
		FactorDto factor = null;
		ArrayList<Integer> weights = new ArrayList<>();
		try {
			conn = dataSource.getConnection();
			String query = "select * from analyzedfactor where id=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, userId);

			resultSet = pstmt.executeQuery();
			ResultSetMetaData metaData = resultSet.getMetaData();
			 
			
			while(resultSet.next()) {
				weights.add(resultSet.getInt("economicStability"));
				weights.add(resultSet.getInt("selfImprovement"));
				weights.add(resultSet.getInt("exercise"));
				weights.add(resultSet.getInt("leisure"));
				weights.add(resultSet.getInt("relSocial"));
				weights.add(resultSet.getInt("relFamily"));

				for(int i = 0; i< weights.size();i++) {
					if(weights.get(i)>100) {weights.set(i,100);}
					if(weights.get(i)<0) {weights.set(i,0);}
				}

				factor = new FactorDto();
				factor.setId(resultSet.getString("id"));
				factor.setPredSatLife(resultSet.getInt("predictedSatLife"));
				factor.setEconomicStability(weights.get(0));
				factor.setSelfImprovement(weights.get(1));
				factor.setExercise(weights.get(2));
				factor.setLeisure(weights.get(3));
				factor.setRelSocial(weights.get(4));
				factor.setRelFamily(weights.get(5));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
				if (resultSet != null) resultSet.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return factor;
	}
	
	// 요인별 가중치 상위 3개
	public RankFactorDto sortFactor(FactorDto factor){
		RankFactorDto rank;
		Map<String,Integer> factorItem = new HashMap<>();
		// 항목, 값 map에 저장
		factorItem.put("경제적 안정성", factor.getEconomicStability());
		factorItem.put("자기계발 활동", factor.getSelfImprovement());
		factorItem.put("신체적 활동", factor.getExercise());
		factorItem.put("여가활동", factor.getLeisure());
		factorItem.put("사회적 관계", factor.getRelSocial());
		factorItem.put("가족관계", factor.getRelFamily());
		
		// 정렬
		rank = new RankFactorDto();
		List<Map.Entry<String, Integer>> entryList = new LinkedList<>(factorItem.entrySet());
		entryList.sort(((o1, o2) -> factorItem.get(o2.getKey()) - factorItem.get(o1.getKey())));
		rank.setFirstClass(entryList.get(0));
		rank.setSecondClass(entryList.get(1));
		rank.setThirdClass(entryList.get(2));
		
		return rank;
	}
	
	// 성별, 학력 문자로 conversion
	public ConditionDto conversionInfo(ConditionDto cond) {
		String gender = cond.getGender();
		String edu = cond.getEdu();
		int age = cond.getBirth();
		
		// gender
		if (gender.equals("1")) {cond.setGender("남자");} 
		if (gender.equals("2")) {cond.setGender("여자");}
		// edu
		if (edu.equals("1")) {cond.setEdu("고등학교 졸업 미만");} 
		if (edu.equals("2")) {cond.setEdu("고등학교 졸업");} 
		if (edu.equals("3")) {cond.setEdu("대학 재학 또는 중퇴");} 
		if (edu.equals("4")) {cond.setEdu("전문대학 졸업");} 
		if (edu.equals("5")) {cond.setEdu("4년제 대학 졸업");}
		if (edu.equals("6")) {cond.setEdu("대학원 재학 또는 졸업");}
		
		return cond;
	}
	
	
	 public String generateRandomId(int length) {// 비회원 : 랜덤 아이디 생성
        String characters = "0123456789abcdefghijklmnopqrstuvwxyz";
        StringBuilder randomString = new StringBuilder();
        Set<Character> uniqueChars = new HashSet<>();

        Random random = new Random();
        while (randomString.length() < length) {
            char randomChar = characters.charAt(random.nextInt(characters.length()));
            if (uniqueChars.add(randomChar)) {
                randomString.append(randomChar);
            }
        }

        return randomString.toString();
    }
	
	
}
