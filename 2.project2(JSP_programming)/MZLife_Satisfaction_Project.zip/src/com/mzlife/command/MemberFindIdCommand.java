package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.MemberDao;

public class MemberFindIdCommand implements MemberCommand {
	MemberDao memberDao;
	public MemberFindIdCommand() {
		memberDao = MemberDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String name= request.getParameter("userName");
		String email= request.getParameter("userEmail");
		String id = memberDao.getUserId(name, email);
		
		request.setAttribute("resultId", id);
	}
}
	
