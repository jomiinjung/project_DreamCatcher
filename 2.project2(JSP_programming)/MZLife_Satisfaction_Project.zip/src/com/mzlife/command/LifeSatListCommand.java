package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.ConditionDao;
import com.mzlife.model.ConditionDto;

public class LifeSatListCommand implements LifeSatCommand {
	ConditionDao condDao;
	public LifeSatListCommand() {
		condDao = ConditionDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		ConditionDto cond = (ConditionDto)request.getAttribute("conditions");

		String userId = cond.getId();
		ConditionDto userInfo = condDao.conversionInfo(condDao.getUserCond(userId));
		request.setAttribute("user", userInfo);
	};
}