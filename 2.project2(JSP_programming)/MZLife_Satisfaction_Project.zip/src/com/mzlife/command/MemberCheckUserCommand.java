package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.MemberDao;

public class MemberCheckUserCommand implements MemberCommand {
	MemberDao memberDao;
	public MemberCheckUserCommand() {
		memberDao = MemberDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String checkId = memberDao.checkUserPw(id, name);
		request.setAttribute("id", checkId);
	}
}