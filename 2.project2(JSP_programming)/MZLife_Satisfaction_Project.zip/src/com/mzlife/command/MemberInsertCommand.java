package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.MemberDao;
import com.mzlife.model.MemberDto;


public class MemberInsertCommand implements MemberCommand {
	MemberDao memberDao;
	public MemberInsertCommand() {
		memberDao = MemberDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		MemberDto member = (MemberDto)request.getAttribute("member");
		int ri = memberDao.insertMember(member);
		request.setAttribute("riJoin", ri);
	}
	
}
