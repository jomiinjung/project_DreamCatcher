package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.MemberDao;

public class MemberChangePwCommand implements MemberCommand {
	MemberDao memberDao;
	public MemberChangePwCommand() {
		memberDao = MemberDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String newPw = request.getParameter("newPw");
		int ri = memberDao.updatePw(newPw,id);
		
		System.out.println("pw update : " + ri);
	}
}