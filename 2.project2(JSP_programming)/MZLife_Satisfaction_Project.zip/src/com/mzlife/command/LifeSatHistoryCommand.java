package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.ConditionDao;
import com.mzlife.model.ConditionDto;
public class LifeSatHistoryCommand implements LifeSatCommand {
	ConditionDao condDao;
	public LifeSatHistoryCommand() {
		condDao = ConditionDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String userId = (String)request.getAttribute("userId");
		boolean isExist = false;
		ConditionDto condition = condDao.getUserCond(userId);
		if(condition == null) {isExist = false;}
		if(condition != null) {
			isExist = true;
			request.setAttribute("conditions", condition);
		}
		
		request.setAttribute("isExist", isExist);
	};
}
