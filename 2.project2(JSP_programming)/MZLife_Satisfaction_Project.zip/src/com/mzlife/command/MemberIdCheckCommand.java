package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.MemberDao;
import com.mzlife.model.MemberDto;


public class MemberIdCheckCommand implements MemberCommand {
	MemberDao memberDao;
	public MemberIdCheckCommand() {
		memberDao = MemberDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("inputId");

		String passId = memberDao.confirmId(id);
		request.setAttribute("passId", passId);
	}
	
}
