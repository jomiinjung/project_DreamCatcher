package com.mzlife.command;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mzlife.model.AnalysisDao;
import com.mzlife.model.RatioDto;

public class LifeAnlysSelectCommand implements LifeAnlysCommand {
	AnalysisDao anlysDao;
	public LifeAnlysSelectCommand() {
		anlysDao = AnalysisDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String ct = request.getParameter("comparison");
		ArrayList<RatioDto> subItems = anlysDao.getRatio(ct);
		
		// condDao에서 받은 객체 배열을 json으로 변환하여 ajax에게 넘김
		// jackson 라이브러리
	    ObjectMapper objectMapper = new ObjectMapper();
	    String json = null;
		try {
			json = objectMapper.writeValueAsString(subItems);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	    response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    try {
			response.getWriter().write(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
