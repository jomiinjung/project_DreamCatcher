package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.command.LifeSatCommand;
import com.mzlife.model.ConditionDao;
import com.mzlife.model.ConditionDto;

public class LifeSatInsertCommand implements LifeSatCommand {
	ConditionDao condDao;
	public LifeSatInsertCommand() {
		condDao = ConditionDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		ConditionDto cond = (ConditionDto)request.getAttribute("conditions");
		
		String userId = condDao.insertCondition(cond);
		condDao.predictLifeSat(userId);
		cond.setId(userId);
		request.setAttribute("conditions", cond);
	};
}
