package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.MemberDao;

public class MemberLoginCommand implements MemberCommand {
	MemberDao memberDao;
	public MemberLoginCommand() {
		memberDao = MemberDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("loginId");
		String pw = request.getParameter("loginPw");
		String result = null;
		int ri = memberDao.userCheck(id, pw);
		if(ri == -1) {result = "아이디가 존재하지 않습니다.";}
		if(ri == 0) {result = "비밀번호가 일치하지 않습니다.";}
		if(ri == 1) {result = "로그인이 되었습니다.";}
		

		request.setAttribute("ri", ri);
		request.setAttribute("result", result);
	}
}
	