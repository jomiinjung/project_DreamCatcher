 package com.mzlife.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mzlife.model.CompScoreDto;
import com.mzlife.model.ConditionDao;
import com.mzlife.model.ConditionDto;
import com.mzlife.model.FactorDto;
import com.mzlife.model.RankFactorDto;

public class LifeSatInflCommand implements LifeSatCommand {
	ConditionDao condDao;
	public LifeSatInflCommand() {
		condDao = ConditionDao.getInstance();
	}
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		ConditionDto info = (ConditionDto)request.getAttribute("user");
		CompScoreDto compare = condDao.getCompareScore(info.getId());
		FactorDto factor = condDao.getFactor(info.getId());
		RankFactorDto ranking = condDao.sortFactor(factor);
		
		request.setAttribute("user", info);
		request.setAttribute("avg", compare);
		request.setAttribute("factor", factor);
		request.setAttribute("ranking", ranking);
	};
}
