package com.mzlife.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface LifeSatCommand {
	void execute(HttpServletRequest request, HttpServletResponse response);
}
