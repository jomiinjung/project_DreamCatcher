package com.mzlife.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mzlife.command.LifeAnlysCommand;
import com.mzlife.command.LifeAnlysSelectCommand;
import com.mzlife.command.LifeSatCommand;
import com.mzlife.command.LifeSatHistoryCommand;
import com.mzlife.command.LifeSatInflCommand;
import com.mzlife.command.LifeSatInsertCommand;
import com.mzlife.command.LifeSatListCommand;
import com.mzlife.command.MemberChangePwCommand;
import com.mzlife.command.MemberCheckUserCommand;
import com.mzlife.command.MemberCommand;
import com.mzlife.command.MemberFindIdCommand;
import com.mzlife.command.MemberIdCheckCommand;
import com.mzlife.command.MemberInsertCommand;
import com.mzlife.command.MemberLoginCommand;
import com.mzlife.model.ConditionDto;
import com.mzlife.model.MemberDto;


/**
 * Servlet implementation class LifeSatController
 */
@WebServlet("*.do")
public class LifeSatController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LifeSatController() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost");
		actionDo(request, response);
	}
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		System.out.println("actionDo");
		
		request.setCharacterEncoding("UTF-8");
		HttpSession session = null;
		LifeSatCommand lifeSat = null;
		LifeAnlysCommand lifeAnl = null;
		MemberCommand lifeMember = null;
		
		String viewPage = null;
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length()+6);
		
		if(com.equals("/analySatLife.do")) {
			session = request.getSession();
			String id = (String)session.getAttribute("id");
			if(id!=null) {
				request.setAttribute("userId", id);
				lifeSat = new LifeSatHistoryCommand();
				lifeSat.execute(request, response);
				boolean isExist = (boolean)request.getAttribute("isExist");
				ConditionDto condition = (ConditionDto)request.getAttribute("conditions");
				if(isExist) {
					request.setAttribute("conditions",condition);
					viewPage = "list.do";
				}
				if(!isExist) {viewPage = "mz_satisfaction.jsp";}
			}
			if(id==null) {viewPage = "mz_satisfaction.jsp";}

		}else if(com.equals("/insert.do")) { 
			// 사용자가 입력한 정보 DB 추가
			session = request.getSession();
			String id = (String)session.getAttribute("id");
			if(id==null) {id = null;} // 로그인 하지 않은 경우
			ConditionDto condition = new ConditionDto();
			condition.setId(id);
			condition.setName(request.getParameter("name"));
			condition.setBirth(Integer.parseInt(request.getParameter("birth")));
			condition.setGender(request.getParameter("gender"));
			condition.setEdu(request.getParameter("edu"));
			condition.setEconomicStability(Integer.parseInt(request.getParameter("economicStability")));
			condition.setSelfImprovement(Integer.parseInt(request.getParameter("selfImprovement")));
			condition.setExercise(Integer.parseInt(request.getParameter("exercise")));
			condition.setLeisure(Integer.parseInt(request.getParameter("leisure")));
			condition.setRelSocial(Integer.parseInt(request.getParameter("relSocial")));
			condition.setRelFamily(Integer.parseInt(request.getParameter("relFamily")));
			condition.setSatLife(Integer.parseInt(request.getParameter("satLife")));
			request.setAttribute("conditions",condition);
			
			lifeSat = new LifeSatInsertCommand();
			lifeSat.execute(request, response);
			viewPage = "list.do";
		}else if(com.equals("/list.do")) { 
			// 예측 만족도 산출 후 DB 입력
			System.out.println("list");
			lifeSat = new LifeSatListCommand();
			lifeSat.execute(request, response);
			viewPage="factor.do";
		}else if(com.equals("/factor.do")) {
			// 만족도에 영향을 주는 요인 산출
			lifeSat = new LifeSatInflCommand();
			lifeSat.execute(request, response);
			viewPage="mz_satisfaction.jsp";
		}else if(com.equals("/compare.do")) {
			// 통계 분석 기능 : ajax로 json 전송
			lifeAnl = new LifeAnlysSelectCommand();
			lifeAnl.execute(request, response);
			// view page로 foward 하지 않고 LifeAnlysSelectCommand에서 view단의 ajax에게 json 데이터 넘김
			return;
		}else if(com.equals("/logout.do")) {
			session = request.getSession();
			if(session != null && session.getAttribute("id") != null) {
				session.invalidate();
				response.sendRedirect("main.jsp");
			}
			return;
		}else if(com.equals("/member/idCheck.do")){
			// 회원가입 - 아이디 중복확인
			lifeMember = new MemberIdCheckCommand();
			lifeMember.execute(request, response);
			viewPage="join.jsp";
		}else if(com.equals("/member/join.do")){
			// 회원가입
			MemberDto member = new MemberDto();
			member.setUserId(request.getParameter("userId"));
			member.setUserPw(request.getParameter("userPw"));
			member.setUserName(request.getParameter("userName"));
			member.setUserEmail(request.getParameter("userEmail"));
			member.setUserTel(Integer.parseInt(request.getParameter("userTel")));
			member.setAgree(request.getParameter("agree"));
			member.setValidity(request.getParameter("validity"));
			request.setAttribute("member",member);
			
			lifeMember = new MemberInsertCommand();
			lifeMember.execute(request, response);
			viewPage="join_complete.jsp";
		}else if(com.equals("/member/login.do")) {
			// 로그인
			String id = request.getParameter("loginId");
			String pw = request.getParameter("loginPw");
			request.setAttribute("loginId",id);
			request.setAttribute("loginPw",pw);
			
			lifeMember = new MemberLoginCommand();
			lifeMember.execute(request, response);
			
			String result = (String) request.getAttribute("result");
		    int ri = (int) request.getAttribute("ri");
		    // 로그인 실패
		    if(ri==0 || ri==-1) {
		    	request.setAttribute("result", result);
		    	request.setAttribute("ri", ri);
				viewPage="login.jsp";
		    }
		    // 로그인 성공
		    if(ri==1) {
		    	session = request.getSession();
		    	session.setAttribute("id",id);
		    	request.setAttribute("ri", ri);
				viewPage="/views/main.jsp";
		    }
		}else if(com.equals("/member/findId.do")) {
			// 아이디 찾기
			lifeMember = new MemberFindIdCommand();
			lifeMember.execute(request, response);
			viewPage="find_id_result.jsp";
		}else if(com.equals("/member/checkUser.do")) {
			// 회원 인증
			lifeMember = new MemberCheckUserCommand();
			lifeMember.execute(request, response);
			String id = (String) request.getAttribute("id");
	    	request.setAttribute("id", id);
			viewPage="find_pw_change.jsp";
		}else if(com.equals("/member/changePw.do")) {
			// 비밀번호 변경
			lifeMember = new MemberChangePwCommand();
			lifeMember.execute(request, response);
			
			viewPage="login.jsp";
		}
		

		System.out.println("viewPage : " + viewPage);
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request,response);
	}
}
